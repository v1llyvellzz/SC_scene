--- A simple wrapper around SendNUIMessage that you can use to
--- dispatch actions to the React frame.
---
---@param action string The action you wish to target
---@param data any The data you wish to send along with this action
function SendReactMessage(action, data)
  SendNUIMessage({
    action = action,
    data = data
  })
end

---Credit https://github.com/ItsANoBrainer/qb-scenes/blob/master/client/utils.lua
function RotationToDirection(rotation)
	local adjustedRotation =
	{
		x = (math.pi / 180) * rotation.x,
		y = (math.pi / 180) * rotation.y,
		z = (math.pi / 180) * rotation.z
	}
	local direction =
	{
		x = -math.sin(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)),
		y = math.cos(adjustedRotation.z) * math.abs(math.cos(adjustedRotation.x)),
		z = math.sin(adjustedRotation.x)
	}
	return direction
end

function RayCastGamePlayCamera(distance)
    local cameraRotation = GetGameplayCamRot()
	local cameraCoord = GetGameplayCamCoord()
	local direction = RotationToDirection(cameraRotation)
	local destination =
	{
		x = cameraCoord.x + direction.x * distance,
		y = cameraCoord.y + direction.y * distance,
		z = cameraCoord.z + direction.z * distance
	}
	local _, hit, endCoords, _, _ = GetShapeTestResult(StartShapeTestRay(cameraCoord.x, cameraCoord.y, cameraCoord.z, destination.x, destination.y, destination.z, -1, cache.ped, 0))
	return hit == 1, endCoords
end

function CanPlayerSeeScene(sceneCoords)
    local coords = GetEntityCoords(cache.ped)
	local _, hit, _, _, _ = GetShapeTestResult(StartShapeTestRay(coords.x, coords.y, coords.z, sceneCoords.x, sceneCoords.y, sceneCoords.z, -1, cache.ped, 0))
	return hit == 1
end

function rgbToHex(hex)
    hex = hex:gsub("#","")
    return tonumber("0x"..hex:sub(1,2)), tonumber("0x"..hex:sub(3,4)), tonumber("0x"..hex:sub(5,6))
end

function Draw2DText(content, font, colour, scale, x, y)
    SetTextFont(font)
    SetTextScale(scale, scale)
    SetTextColour(colour[1],colour[2],colour[3], 255)
    SetTextEntry("STRING")
    SetTextDropShadow(0, 0, 0, 0,255)
    SetTextDropShadow()
    SetTextEdge(4, 0, 0, 0, 255)
    SetTextOutline()
    AddTextComponentString(content)
    DrawText(x, y)
end

---Credit https://github.com/andristum/dpscenes
function SceneAge(sec)
	local Seconds = tonumber(sec)
	if Seconds <= 0 then
		return {Hours = 0, Minutes = 0}
	else
		Hours = string.format("%02.f", math.floor(Seconds/3600))
		Minutes = string.format("%02.f", math.floor(Seconds/60-(Hours*60)))
		return {Hours = Hours, Minutes = Minutes}
	end
end